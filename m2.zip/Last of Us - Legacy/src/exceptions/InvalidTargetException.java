package exceptions;

public class InvalidTargetException extends GameActionException {

	public InvalidTargetException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidTargetException(String message) {
		super(message);
	}
}
